# Chicken POS PWA (starter build)

An installable, Android-friendly point-of-sale web app starter for a chicken shop.

## Included in this starter
- POS cart and checkout
- Four branch selector with separate product stock and branch-specific sales/expenses
- Product stock, selling price and cost price management
- Cash, M-Pesa, card and credit payment recording
- Printable receipt through browser print dialog
- Daily sales, estimated gross profit, expenses and estimated net report
- JSON export backup
- PWA manifest and service worker for offline app shell
- Local browser storage for offline records

## Important limitations
- **Online branch sync is not implemented yet.** The settings screen accepts Supabase credentials for the next setup stage, but it does not send or synchronize records. Do not treat the four branch selector as cross-device sync.
- Data is stored in this browser on this device. Clearing browser/site data can erase it. Export backups regularly.
- This starter has no user accounts, staff permissions, audit trail, server backup, tax/eTIMS integration, or automatic M-Pesa confirmation.
- Use HTTPS hosting for installation and service-worker offline support. Opening `index.html` directly from a file manager may not enable PWA installation/offline caching.
- Sample products and stock are demo values; edit them before real use.

## Test locally
For a developer computer, serve the folder over localhost, for example:
`python -m http.server 8000`
Then open `http://localhost:8000`.

## Deploy for free
1. Create a GitHub account and a new repository.
2. Upload all files in this folder to the repository root.
3. In the repository, open **Settings → Pages**.
4. Set deployment to **Deploy from a branch**, choose `main` and `/ (root)`, then save.
5. Wait for GitHub Pages to publish the HTTPS site.
6. Open the published URL in Chrome on Android, tap the three-dot menu, then **Install app** or **Add to Home screen**.
7. Open the app online once before testing offline; keep the browser installed and do not clear site storage.

## Next: Supabase sync
Create a Supabase project, then create tables for branches, products, sales, sale_items, expenses, and users. Add Row Level Security policies so each staff account can access only authorized branches. Implement an authenticated sync queue that uploads local transactions and downloads updates. Never put a Supabase service-role key in a browser app; only the anon/public key belongs client-side, protected by correct RLS policies.

This starter is a prototype, not yet a production-ready multi-branch POS. Test with sample transactions and backups before using it for real sales.